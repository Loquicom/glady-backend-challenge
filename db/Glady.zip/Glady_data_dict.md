| Attribut | Informations |
|----------|-------------|
| co_id | _serial_ |
| name | _varchar(255)_ |
| balance | _decimal_ |
| em_id | _serial_ |
| firstname | _varchar(255)_ |
| lastname | _varchar(255)_ |
| de_id | _serial_ |
| amount | _decimal_ |
| date | _date_ |
| expire | _date_ |
| type | _varchar(5)_ |