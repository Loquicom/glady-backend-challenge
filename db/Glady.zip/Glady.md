**COMPANY** (<ins>co_id</ins>, name, balance)  
**EMPLOYEE** (<ins>em_id</ins>, firstname, lastname, _co_id_)  
**DEPOSIT** (<ins>de_id</ins>, amount, date, expire, type, _em_id_)